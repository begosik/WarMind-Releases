# WarMind Launcher

## Установка и запуск

1. Скачайте **WarMind-Launcher-win64.zip** и распакуйте весь архив в папку с правом записи. [Релизы WarMind](https://github.com/begosik/WarMind-Releases/releases)
2. Откройте лаунчер 1.0.18 или новее и выберите канал **Тестовая** для сборок с буквой, например WarMind 0.0a1. Канал **Публичная** предназначен для версий с числовым номером.
3. Нажмите **Скачать**, выберите язык и нажмите **Запуск**. Для каждой версии скачивается один архив со всеми её локализациями. При смене языка лаунчер использует уже установленные файлы. Если в сборке отсутствует выбранный язык, мод запустится на английском.
4. Нажмите на номер версии, чтобы открыть список сборок или сразу проверить обновления. Отдельный токен GitHub для публичных релизов не требуется.

Лаунчер скачивает ZIP с Google Drive, а BIG лобби и DLL — с GitHub. Скачанные сборки хранятся в `Документы\WarMind`. Лаунчер также показывает сборки из `Документы\Red Alert 3\Mods\WarMind`, куда Mod Studio может выводить их при разработке. В режиме «Последняя доступная» сравниваются версии из обеих папок и GitHub. Например, готовая локальная 0.0a2 имеет приоритет перед релизной 0.0a1. Очистка касается только скачанных сборок в `Документы\WarMind`.

Установленная версия определяется по SkuDef и файлам сборки, включая BIG лобби и DLL. Для всех языков используется один SkuDef, например `WarMind_0.0a1.skudef`. При запуске лаунчер обновляет в нём ссылку на языковой BIG. Настройки и журналы находятся рядом с EXE лаунчера.

## Сборка мода и лобби

- Nope.mp4 собирает WOD в RA3 Mod Studio и упаковывает четыре BIG и общий SkuDef в один ZIP. [Русская инструкция по сборке WOD](https://github.com/AlekseyYurchenkov/WOD-Source-Code/pull/4/files)
- Общий APT-интерфейс лобби берёт подписи по ключам из английского `Mod.str` и русского `gamestrings.csf`. [Пул-реквест с ключами локализации](https://github.com/AlekseyYurchenkov/WOD-Source-Code/pull/5)
- Шаблоны фракций и сетевые настройки должны быть совместимы с `WarMindExtension.dll`.

К упаковке подготовьте в одной папке `WarMind_<версия>_Streams.big`, `WarMind_<версия>_Misc.big`, `WarMind_<версия>_English.big`, `WarMind_<версия>_Russian.big` и `WarMind_<версия>.skudef`. Общий SkuDef должен ссылаться на Streams и Misc. Команда упаковки создаёт обычный ZIP для обоих каналов.

```powershell
python tools/package_warmind.py .\build\Install 0.0a .\warmind-multilingual.zip
```

| Канал | Тег GitHub | Файлы релиза |
| --- | --- | --- |
| Тестовый | `warmind-0.0a1` | `WarMind_0.0a1_Lobby.big`, `WarMindExtension.dll` |
| Публичный | `warmind-1.0` | `WarMind_1.0_Lobby.big`, `WarMindExtension.dll` |
| Лаунчер | `launcher-X.Y.Z` | `WarMind-Launcher-win64.zip`, `WoDLauncher.zip` |

Загрузите ZIP на Google Drive и откройте доступ всем, у кого есть ссылка. Вставьте ссылку на файл в описание GitHub-релиза. Имя ZIP на Диске может быть любым.

```text
https://drive.google.com/file/d/FILE_ID/view
```

Прикрепите BIG лобби и DLL к релизу GitHub отдельными файлами. Готовые файлы можно взять из предыдущего релиза, если они совместимы со сборкой. В имени BIG лобби укажите номер выпускаемого мода. Для версии с буквой отметьте **Pre-release**. [Создать релиз в WarMind Releases](https://github.com/begosik/WarMind-Releases/releases/new)

Архив `WoDLauncher.zip` содержит EXE для автообновления. Для чистой установки используйте полный `WarMind-Launcher-win64.zip`.

## Локальный запуск исходников

```powershell
python -m pip install -r requirements.txt
python main.py
```

Для сборки требуется Python 3.14 x64. Лаунчер использует ресурсы проекта и шрифт из установленной Red Alert 3.
